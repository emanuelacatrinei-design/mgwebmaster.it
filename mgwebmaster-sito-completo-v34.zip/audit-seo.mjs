import fs from 'node:fs';
import path from 'node:path';

const root=path.resolve('dist');
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);e.isDirectory()?walk(p):e.name==='index.html'&&files.push(p)}}
walk(root);
const pages=[];const errors=[];const inbound=new Map();
const stop=new Set('come della delle degli della del per con che una uno un gli le il lo la nel nei nelle alla alle dai dal dei più tuo tua mg webmaster'.split(' '));
const text=s=>s.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&[a-z]+;/gi,' ').replace(/\s+/g,' ').trim().toLowerCase();
for(const file of files){
  const html=fs.readFileSync(file,'utf8');if(/http-equiv="refresh"/.test(html))continue;
  const rel=path.relative(root,file),main=html.match(/<main[\s\S]*?<\/main>/)?.[0]||'';
  const title=html.match(/<title>([^<]+)<\/title>/)?.[1]||'',desc=html.match(/<meta name="description" content="([^"]+)"/)?.[1]||'';
  const h1=[...html.matchAll(/<h1\b/g)].length,h2=[...main.matchAll(/<h2\b/g)].length;
  if(h1!==1)errors.push(`${rel}: trovati ${h1} H1`);if(h2<1)errors.push(`${rel}: H2 mancante`);
  if(desc.length<100||desc.length>180)errors.push(`${rel}: meta description di ${desc.length} caratteri`);
  for(const img of html.matchAll(/<img\b[^>]*>/g)){if(!/\balt="[^"]*"/.test(img[0]))errors.push(`${rel}: immagine senza attributo ALT`)}
  if(!html.includes('rel="apple-touch-icon"'))errors.push(`${rel}: Apple Touch Icon non collegata`);
  if(!html.includes('/cookie-consent.js')||!html.includes('data-cookie-banner'))errors.push(`${rel}: gestione consenso cookie mancante`);
  if(!html.includes('share-section'))errors.push(`${rel}: sezione condivisione mancante`);
  const body=text(main),keywords=[...new Set(text(title).split(/[^a-zà-ù0-9]+/).filter(w=>w.length>3&&!stop.has(w)))];
  const present=keywords.filter(w=>body.includes(w));if(keywords.length&&present.length/keywords.length<.6)errors.push(`${rel}: parole chiave del title poco presenti nel testo (${present.length}/${keywords.length})`);
  const anchors=[...main.matchAll(/<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g)].map(m=>({href:m[1],label:text(m[2])}));
  const seen=new Set();for(const a of anchors){if(seen.has(a.label))errors.push(`${rel}: anchor contestuale duplicata “${a.label}”`);seen.add(a.label)}
  for(const a of html.matchAll(/<a\b[^>]*href="(\/[^"]*)"/g))inbound.set(a[1],(inbound.get(a[1])||0)+1);
  pages.push({rel,title,desc,h1,h2,images:[...html.matchAll(/<img\b/g)].length,internal:anchors.filter(a=>a.href.startsWith('/')).length});
}
for(const p of pages){const route=p.rel==='index.html'?'/':`/${p.rel.replace(/index\.html$/,'')}`;if(route!=='/'&&!inbound.get(route))errors.push(`${p.rel}: nessun collegamento interno in entrata`)}
if(errors.length){console.error(errors.join('\n'));process.exit(1)}
console.log(`Audit SEO superato: ${pages.length} pagine indicizzabili, H1/H2, description, keyword, ALT, AI Mode, link interni, anchor, condivisione e Apple Touch Icon verificati.`);
