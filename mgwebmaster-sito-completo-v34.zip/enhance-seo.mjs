import fs from 'node:fs';
import path from 'node:path';

const root=path.resolve('dist');
const service='/servizi/';
const links={
  home:['/','MG Webmaster: siti web a Perugia'], services:[service,'Scopri i servizi web a Perugia'],
  seo:[`${service}consulenza-seo/`,'Consulenza SEO e GEO a Perugia'],
  local:[`${service}seo-locale-google-maps/`,'Google Maps e SEO locale in Umbria'],
  web:[`${service}realizzazione-siti-web/`,'Progettazione di siti web veloci e responsive'],
  hosting:[`${service}dominio-hosting/`,'Dominio e hosting professionale'],
  ads:[`${service}google-ads/`,'Campagne Google Ads per aziende'],
  care:[`${service}assistenza-manutenzione/`,'Assistenza e manutenzione del sito'],
  prices:['/prezzi/','Prezzi indicativi e preventivo trasparente'],
  projects:['/progetti/','Guarda i progetti realizzati'], blog:['/blog/','Guide su siti web, SEO e marketing'],
  about:['/chi-sono/','Conosci Emanuel Acatrinei'],
  contact:['/contatti/','Parliamo del tuo progetto digitale']
};
const routeSets=[
  [/consulenza-seo|seo-locale-perugia-umbria/,['local','web','blog']],
  [/google-maps|google-business/,['local','seo','contact']],
  [/dominio-hosting/,['hosting','web','care']],
  [/google-ads/,['ads','prices','contact']],
  [/social-ads|facebook-instagram/,['blog','web','contact']],
  [/design|identità/,['web','projects','contact']],
  [/prezzi|quanto-costa/,['prices','web','contact']],
  [/progetti|sartoria-italiana|7-giorni/,['projects','web','prices']],
  [/chi-sono/,['services','projects','contact']],
  [/contatti/,['services','prices','about']],
  [/blog/,['seo','local','services']],
  [/servizi/,['web','seo','local']],
  [/index\.html$/,['services','projects','about']]
];
const esc=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const clean=s=>s.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
function selected(file){const rel=file.slice(root.length+1);return routeSets.find(([re])=>re.test(rel))?.[1]||['services','blog','contact'];}
function section(file,html){
  const canonical=html.match(/<link rel="canonical" href="([^"]+)"/)?.[1]||'';
  const h1=clean(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/)?.[1]||'');
  const desc=html.match(/<meta name="description" content="([^"]+)"/)?.[1]||'';
  const isLegal=/privacy|cookie-policy/.test(file);
  const related=selected(file).map(key=>links[key]).filter(([href])=>!canonical.endsWith(href)).slice(0,3);
  const relatedHtml=`<section class="section related-pages" aria-labelledby="related-title"><div class="container"><h2 id="related-title">Approfondimenti collegati</h2><div class="related-links">${related.map(([href,text])=>`<a href="${href}">${text}<span aria-hidden="true">→</span></a>`).join('')}</div></div></section>`;
  const u=encodeURIComponent(canonical),t=encodeURIComponent(h1);
  const share=`<section class="section share-section" aria-labelledby="share-title"><div class="container"><h2 id="share-title">Condividi questa pagina</h2><p>Se queste informazioni possono essere utili, condividile con chi sta sviluppando la propria presenza online.</p><div class="share-buttons"><a class="share-button facebook" href="https://www.facebook.com/sharer/sharer.php?u=${u}" target="_blank" rel="noopener noreferrer" aria-label="Condividi su Facebook">Facebook</a><a class="share-button pinterest" href="https://pinterest.com/pin/create/button/?url=${u}&description=${t}" target="_blank" rel="noopener noreferrer" aria-label="Condividi su Pinterest">Pinterest</a><a class="share-button email" href="mailto:?subject=${t}&body=${u}" aria-label="Condividi tramite email">Email</a><a class="share-button whatsapp" href="https://wa.me/?text=${t}%20${u}" target="_blank" rel="noopener noreferrer" aria-label="Condividi su WhatsApp">WhatsApp</a><button class="share-button tiktok" type="button" data-native-share aria-label="Condividi tramite TikTok o un’altra app">TikTok</button><button class="share-button native-share" type="button" data-native-share aria-label="Apri il menu di condivisione del dispositivo">Condividi</button></div><p class="share-feedback" role="status" aria-live="polite"></p></div></section>`;
  return relatedHtml+share;
}
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(e.name==='index.html'){let html=fs.readFileSync(p,'utf8');if(/http-equiv="refresh"/.test(html))continue;if(!html.includes('rel="apple-touch-icon"'))html=html.replace('</head>','<link rel="apple-touch-icon" sizes="180x180" href="/assets/apple-touch-icon.png"></head>');if(!html.includes('share-section'))html=html.replace('</main>',section(p,html)+'</main>');fs.writeFileSync(p,html)}}}
walk(root);
