import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('dist');
const files=[];
function walk(dir){for(const name of fs.readdirSync(dir)){const file=path.join(dir,name);const stat=fs.statSync(file);stat.isDirectory()?walk(file):files.push(file)}}
walk(root);
const broken=[];
const titles=new Map();
let indexable=0;
for(const file of files.filter(file=>file.endsWith('.html'))){
  const html=fs.readFileSync(file,'utf8');
  for(const match of html.matchAll(/(?:href|src)="(\/[^"?#]*)/g)){
    const url=match[1];
    const target=url==='/'?path.join(root,'index.html'):url.endsWith('/')?path.join(root,url,'index.html'):path.join(root,url);
    if(!fs.existsSync(target))broken.push(`${path.relative(root,file)} -> ${url}`);
  }
  if(!/<title>[^<]+<\/title>/.test(html))broken.push(`${path.relative(root,file)} -> title mancante`);
  const isRedirect=/<meta http-equiv="refresh"/.test(html);
  if(!/<h1[ >]/.test(html)&&!file.endsWith('404.html')&&!isRedirect)broken.push(`${path.relative(root,file)} -> H1 mancante`);
  if(!isRedirect&&!/name="robots" content="noindex/.test(html)&&!file.endsWith('404.html')){
    indexable++;
    const title=html.match(/<title>([^<]+)<\/title>/)?.[1]||'';
    const description=html.match(/<meta name="description" content="([^"]+)"/)?.[1]||'';
    const canonical=html.match(/<link rel="canonical" href="([^"]+)"/)?.[1]||'';
    if(title.length<30||title.length>70)broken.push(`${path.relative(root,file)} -> title lungo ${title.length}`);
    if(description.length<100||description.length>180)broken.push(`${path.relative(root,file)} -> description lunga ${description.length}`);
    if(!canonical.startsWith('https://www.mgwebmaster.it/'))broken.push(`${path.relative(root,file)} -> canonical non valido`);
    if(titles.has(title))broken.push(`${path.relative(root,file)} -> title duplicato con ${titles.get(title)}`);else titles.set(title,path.relative(root,file));
    for(const block of html.matchAll(/<script type="application\/ld\+json">([^<]+)<\/script>/g)){
      try{JSON.parse(block[1])}catch{broken.push(`${path.relative(root,file)} -> JSON-LD non valido`)}
    }
  }
}
if(broken.length){console.error(broken.join('\n'));process.exit(1)}
console.log(`Verificati ${files.filter(file=>file.endsWith('.html')).length} file HTML (${indexable} indicizzabili): link, metadati e risorse validi.`);
